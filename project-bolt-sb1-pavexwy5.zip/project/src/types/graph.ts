export interface Node {
  id: string;
  x: number;
  y: number;
  isTrafficLight?: boolean;
  lightState?: 'red' | 'green' | 'yellow';
}

export interface Edge {
  from: string;
  to: string;
  weight: number;
}

export interface Graph {
  nodes: Node[];
  edges: Edge[];
}