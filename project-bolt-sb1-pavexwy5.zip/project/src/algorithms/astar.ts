import { Graph, Node } from '../types/graph';

interface NodeWithCost {
  id: string;
  f: number;
  g: number;
}

function heuristic(node1: Node, node2: Node): number {
  return Math.sqrt(Math.pow(node2.x - node1.x, 2) + Math.pow(node2.y - node1.y, 2));
}

export function astar(graph: Graph, startId: string, endId: string): string[] {
  const start = graph.nodes.find(n => n.id === startId)!;
  const end = graph.nodes.find(n => n.id === endId)!;
  
  const openSet = new Set<string>([startId]);
  const cameFrom: Record<string, string> = {};
  
  const gScore: Record<string, number> = {};
  const fScore: Record<string, number> = {};
  
  graph.nodes.forEach(node => {
    gScore[node.id] = Infinity;
    fScore[node.id] = Infinity;
  });
  
  gScore[startId] = 0;
  fScore[startId] = heuristic(start, end);
  
  while (openSet.size > 0) {
    let current = '';
    let lowestF = Infinity;
    
    openSet.forEach(nodeId => {
      if (fScore[nodeId] < lowestF) {
        lowestF = fScore[nodeId];
        current = nodeId;
      }
    });
    
    if (current === endId) {
      const path: string[] = [current];
      while (current in cameFrom) {
        current = cameFrom[current];
        path.unshift(current);
      }
      return path;
    }
    
    openSet.delete(current);
    
    graph.edges
      .filter(edge => edge.from === current)
      .forEach(edge => {
        const tentativeGScore = gScore[current] + edge.weight;
        
        if (tentativeGScore < gScore[edge.to]) {
          cameFrom[edge.to] = current;
          gScore[edge.to] = tentativeGScore;
          fScore[edge.to] = gScore[edge.to] + heuristic(
            graph.nodes.find(n => n.id === edge.to)!,
            end
          );
          openSet.add(edge.to);
        }
      });
  }
  
  return [];
}