import { Graph, Node } from '../types/graph';

interface Distance {
  [key: string]: number;
}

interface Previous {
  [key: string]: string | null;
}

export function dijkstra(graph: Graph, start: string, end: string): string[] {
  const distances: Distance = {};
  const previous: Previous = {};
  const unvisited = new Set<string>();

  // Initialize distances
  graph.nodes.forEach(node => {
    distances[node.id] = Infinity;
    previous[node.id] = null;
    unvisited.add(node.id);
  });
  distances[start] = 0;

  while (unvisited.size > 0) {
    // Find node with minimum distance
    let minDistance = Infinity;
    let current = '';
    unvisited.forEach(nodeId => {
      if (distances[nodeId] < minDistance) {
        minDistance = distances[nodeId];
        current = nodeId;
      }
    });

    if (current === end) break;
    unvisited.delete(current);

    // Update distances to neighbors
    graph.edges
      .filter(edge => edge.from === current)
      .forEach(edge => {
        const alt = distances[current] + edge.weight;
        if (alt < distances[edge.to]) {
          distances[edge.to] = alt;
          previous[edge.to] = current;
        }
      });
  }

  // Reconstruct path
  const path: string[] = [];
  let current = end;
  while (current) {
    path.unshift(current);
    current = previous[current] || '';
  }
  return path;
}