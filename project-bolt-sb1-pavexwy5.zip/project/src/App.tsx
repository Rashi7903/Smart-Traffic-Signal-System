import React, { useState, useEffect } from 'react';
import Canvas from './components/Canvas';
import ExplanationPanel from './components/ExplanationPanel';
import { Graph } from './types/graph';
import { dijkstra } from './algorithms/dijkstra';
import { astar } from './algorithms/astar';
import { Play, Pause, RotateCcw } from 'lucide-react';

const initialGraph: Graph = {
  nodes: [
    { id: 'A', x: 100, y: 100 },
    { id: 'B', x: 300, y: 100, isTrafficLight: true, lightState: 'red' },
    { id: 'C', x: 500, y: 100 },
    { id: 'D', x: 100, y: 300 },
    { id: 'E', x: 300, y: 300, isTrafficLight: true, lightState: 'green' },
    { id: 'F', x: 500, y: 300 },
    { id: 'G', x: 100, y: 500 },
    { id: 'H', x: 300, y: 500, isTrafficLight: true, lightState: 'red' },
    { id: 'I', x: 500, y: 500 },
  ],
  edges: [
    { from: 'A', to: 'B', weight: 4 },
    { from: 'B', to: 'C', weight: 3 },
    { from: 'A', to: 'D', weight: 3 },
    { from: 'B', to: 'E', weight: 5 },
    { from: 'C', to: 'F', weight: 2 },
    { from: 'D', to: 'E', weight: 2 },
    { from: 'E', to: 'F', weight: 4 },
    { from: 'D', to: 'G', weight: 4 },
    { from: 'E', to: 'H', weight: 3 },
    { from: 'F', to: 'I', weight: 5 },
    { from: 'G', to: 'H', weight: 2 },
    { from: 'H', to: 'I', weight: 6 },
  ],
};

function App() {
  const [graph, setGraph] = useState<Graph>(initialGraph);
  const [algorithm, setAlgorithm] = useState<'dijkstra' | 'astar'>('dijkstra');
  const [path, setPath] = useState<string[]>([]);
  const [isSimulating, setIsSimulating] = useState(false);
  const [startNode] = useState('A');
  const [endNode] = useState('I');

  const calculatePath = () => {
    const newPath = algorithm === 'dijkstra' 
      ? dijkstra(graph, startNode, endNode)
      : astar(graph, startNode, endNode);
    setPath(newPath);
  };

  useEffect(() => {
    calculatePath();
  }, [algorithm, graph]);

  const toggleSimulation = () => {
    setIsSimulating(!isSimulating);
  };

  const resetSimulation = () => {
    setIsSimulating(false);
    setGraph(initialGraph);
    setPath([]);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-gray-800 mb-8">
          Smart Traffic Signal System
        </h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <div className="flex justify-between items-center mb-6">
                <div className="space-x-4">
                  <button
                    onClick={() => setAlgorithm('dijkstra')}
                    className={`px-4 py-2 rounded-md ${
                      algorithm === 'dijkstra'
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-200 text-gray-700'
                    }`}
                  >
                    Dijkstra
                  </button>
                  <button
                    onClick={() => setAlgorithm('astar')}
                    className={`px-4 py-2 rounded-md ${
                      algorithm === 'astar'
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-200 text-gray-700'
                    }`}
                  >
                    A* Algorithm
                  </button>
                </div>
                
                <div className="space-x-2">
                  <button
                    onClick={toggleSimulation}
                    className="p-2 rounded-md bg-green-500 text-white hover:bg-green-600"
                  >
                    {isSimulating ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={resetSimulation}
                    className="p-2 rounded-md bg-gray-500 text-white hover:bg-gray-600"
                  >
                    <RotateCcw className="w-5 h-5" />
                  </button>
                </div>
              </div>
              
              <Canvas graph={graph} path={path} algorithm={algorithm} />
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h2 className="text-xl font-semibold mb-4">Current Path</h2>
              <div className="flex items-center gap-2 text-lg">
                {path.map((nodeId, index) => (
                  <React.Fragment key={nodeId}>
                    <span className="px-3 py-1 bg-blue-100 rounded-md">
                      {nodeId}
                    </span>
                    {index < path.length - 1 && (
                      <span className="text-gray-400">→</span>
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
          
          <ExplanationPanel algorithm={algorithm} />
        </div>
      </div>
    </div>
  );
}

export default App;