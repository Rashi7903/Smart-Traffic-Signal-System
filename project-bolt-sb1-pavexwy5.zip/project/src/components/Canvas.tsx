import React, { useRef, useEffect } from 'react';
import { Graph, Node, Edge } from '../types/graph';

interface CanvasProps {
  graph: Graph;
  path: string[];
  algorithm: 'dijkstra' | 'astar';
}

const Canvas: React.FC<CanvasProps> = ({ graph, path, algorithm }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const drawNode = (ctx: CanvasRenderingContext2D, node: Node) => {
    ctx.beginPath();
    ctx.arc(node.x, node.y, 20, 0, 2 * Math.PI);
    
    if (node.isTrafficLight) {
      ctx.fillStyle = node.lightState || 'red';
    } else {
      ctx.fillStyle = path.includes(node.id) ? '#4CAF50' : '#2196F3';
    }
    
    ctx.fill();
    ctx.stroke();
    
    ctx.fillStyle = 'white';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(node.id, node.x, node.y);
  };

  const drawEdge = (ctx: CanvasRenderingContext2D, edge: Edge, nodes: Node[]) => {
    const fromNode = nodes.find(n => n.id === edge.from)!;
    const toNode = nodes.find(n => n.id === edge.to)!;
    
    ctx.beginPath();
    ctx.moveTo(fromNode.x, fromNode.y);
    ctx.lineTo(toNode.x, toNode.y);
    
    const isInPath = path.includes(edge.from) && path.includes(edge.to);
    ctx.strokeStyle = isInPath ? '#4CAF50' : '#90A4AE';
    ctx.lineWidth = isInPath ? 3 : 1;
    ctx.stroke();
    
    // Draw weight
    const midX = (fromNode.x + toNode.x) / 2;
    const midY = (fromNode.y + toNode.y) / 2;
    ctx.fillStyle = 'black';
    ctx.fillText(edge.weight.toString(), midX, midY);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw edges first
    graph.edges.forEach(edge => drawEdge(ctx, edge, graph.nodes));

    // Draw nodes on top
    graph.nodes.forEach(node => drawNode(ctx, node));
  }, [graph, path]);

  return (
    <canvas
      ref={canvasRef}
      width={800}
      height={600}
      className="border border-gray-300 rounded-lg"
    />
  );
};

export default Canvas;