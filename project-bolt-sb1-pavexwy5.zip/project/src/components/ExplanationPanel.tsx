import React from 'react';
import { Info, Route, Navigation } from 'lucide-react';

interface ExplanationPanelProps {
  algorithm: 'dijkstra' | 'astar';
}

const ExplanationPanel: React.FC<ExplanationPanelProps> = ({ algorithm }) => {
  const explanations = {
    dijkstra: {
      title: "Dijkstra's Algorithm",
      icon: <Route className="w-6 h-6" />,
      description: "Dijkstra's algorithm finds the shortest path between nodes in a graph. It works by maintaining a set of unvisited nodes and continuously updating the shortest distance to each node from the starting point.",
      benefits: [
        "Guarantees the shortest path",
        "Efficient for traffic routing",
        "Handles variable road conditions",
      ],
    },
    astar: {
      title: "A* Algorithm",
      icon: <Navigation className="w-6 h-6" />,
      description: "A* is an extension of Dijkstra's algorithm that uses heuristics to guide the search towards the goal. It's more efficient for pathfinding as it considers both the distance traveled and the estimated distance to the goal.",
      benefits: [
        "More efficient than Dijkstra's",
        "Optimizes for actual destination",
        "Better for real-time traffic management",
      ],
    },
  };

  const current = explanations[algorithm];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-md">
      <div className="flex items-center gap-3 mb-4">
        {current.icon}
        <h2 className="text-2xl font-bold">{current.title}</h2>
      </div>
      
      <p className="text-gray-600 mb-6">{current.description}</p>
      
      <div className="space-y-4">
        <div className="flex items-start gap-2">
          <Info className="w-5 h-5 text-blue-500 mt-1" />
          <div>
            <h3 className="font-semibold mb-2">Benefits for Traffic Management:</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              {current.benefits.map((benefit, index) => (
                <li key={index}>{benefit}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExplanationPanel;